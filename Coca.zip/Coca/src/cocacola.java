import java.util.Scanner;

public class cocacola {

	public static void main(String[] args) {
		
		cocaVend();

	}

	public static Coca cocaVend(){
		
		Scanner ler = new Scanner(System.in);
		
		int total = 0, coin;
		
		while (total < 45){
			coin=0;
			System.out.println("Insira uma moeda");
			coin = ler.nextInt();
			
		
		if 	(coin!=10 && coin!=25) {
			
				reject(coin);
		}
		
		else {
			receive(coin);
			total += coin;
		}
		
		}
		
		return new Coca();
		
		}
	
private static	void receive(int valor) {
	System.out.println("Valor recebido");
}
private static	void reject(int valor) {
	System.out.println("Valor rejeitado");
}
}

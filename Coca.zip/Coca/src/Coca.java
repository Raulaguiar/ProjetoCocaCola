
public class Coca {

	public Coca() {
		System.out.println("Parabéns você comprou uma Coca");
	}
}
